Deployment of multiple VMs that includes ILB and availability group set-up as well.  Features include:
•	Creates Domain Joined VMs
•	Adds them to availability set
•	Create Internal Load Balancer
•	Configures ILB Rules
•	Configures Probe
•	Creates Probe Test
•	Configures Backed Pool for ILB
•	Adds Availability Set to backend pool

This is a community submission from the Mercury team.  Please reach out to merceng@microsoft.com for questions\consult.
