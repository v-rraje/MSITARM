# Localized messages
data LocalizedData
{
    # culture="en-US"
    ConvertFrom-StringData @'
MissingRoleMessage        = Please ensure that the {0} role is installed 

CheckingTrustMessage      = Checking if Trust between {0} and {1} exists ...
TestTrustMessage          = Trust is {0} between source and target domains and it should be {1} 
RemovingTrustMessage      = Removing trust between {0} and {1} domains ...
DeleteTrustMessage        = Trust between specified domains is now absent                          
AddingTrustMessage        = Adding domain trust between {0} and {1}  ...
SetTrustMessage           = Trust between specified domains is now present

CheckPropertyMessage      = Checking for {0} between domains ...
DesiredPropertyMessage    = {0} between domains is set correctly
NotDesiredPropertyMessage = {0} between domains is not correct. Expected {1}, actual {2}
SetPropertyMessage        = {0} between domains is set
'@
}

function Get-TargetResource
{
    [CmdletBinding()]
    [OutputType([System.Collections.Hashtable])]
    param
    (
        [parameter(Mandatory)]
        [String]$SourceDomainName,

        [parameter(Mandatory)]
        [String]$TargetDomainName,

        [parameter(Mandatory)]
        [PSCredential]$TargetDomainAdministratorCredential,

        [parameter(Mandatory)]
        [ValidateSet("External","Forest")]
        [String]$TrustType,

        [parameter(Mandatory)]
        [ValidateSet("Bidirectional","Inbound","Outbound")]
        [String]$TrustDirection,

        [ValidateSet("Present","Absent")]
        [String]$Ensure = 'Present'
    )

#region Input Validation

    # Load the .NET assembly
    try
    {
        Add-type -AssemblyName System.DirectoryServices
    }
    # If not found, means ADDS role is not installed
    catch
    {
        $missingRoleMessage = $($LocalizedData.MissingRoleMessage) -f 'AD-Domain-Services' 
        New-TerminatingError -errorId ActiveDirectoryRoleMissing -errorMessage $missingRoleMessage -errorCategory NotInstalled
    }

#endregion

    try
    {
        switch ($TrustType)
        {
            'External' {$DomainOrForest = 'Domain'}
            'Forest' {$DomainOrForest = 'Forest'}
        }
        # Create the target object
        $trgDirectoryContext = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext($DomainOrForest,$TargetDomainName, $TargetDomainAdministratorCredential.UserName, $TargetDomainAdministratorCredential.GetNetworkCredential().Password)
        $trgDomain = ([type]"System.DirectoryServices.ActiveDirectory.$DomainOrForest")::"Get$DomainOrForest"($trgDirectoryContext)
        # Create the source object
        $srcDirectoryContext = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext($DomainOrForest,$SourceDomainName)
        $srcDomain = ([type]"System.DirectoryServices.ActiveDirectory.$DomainOrForest")::"Get$DomainOrForest"($srcDirectoryContext)

        # Find trust betwen source & destination.
        $trust = $srcDomain.GetTrustRelationship($trgDomain)

        $Ensure = 'Present'
    }
    catch
    {
        $Ensure = 'Absent'
    }

    # return a credential object without password
    $CIMCredential = New-CimInstance -ClassName MSFT_Credential -ClientOnly `
                                     -Namespace root/microsoft/windows/desiredstateconfiguration `
                                     -Property @{
                                                  UserName = [string]$TargetDomainAdministratorCredential.UserName
                                                  Password = [string]$null
                                                }

    @{
        SourceDomainName = $SourceDomainName
        TargetDomainName = $TargetDomainName
        Ensure           = $Ensure
        TrustType        = $trust.TrustType
        TrustDirection   = $trust.TrustDirection
        TargetDomainAdministratorCredential = $CIMCredential
    }

}

function Set-TargetResource
{
    [CmdletBinding()]
    param
    (
        [parameter(Mandatory)]
        [String]$SourceDomainName,

        [parameter(Mandatory)]
        [String]$TargetDomainName,

        [parameter(Mandatory)]
        [PSCredential]$TargetDomainAdministratorCredential,

        [parameter(Mandatory)]
        [ValidateSet("External","Forest")]
        [String]$TrustType,

        [parameter(Mandatory)]
        [ValidateSet("Bidirectional","Inbound","Outbound")]
        [String]$TrustDirection,

        [ValidateSet("Present","Absent")]
        [String]$Ensure = 'Present'
    )

    if($PSBoundParameters.ContainsKey('Debug')){$null = $PSBoundParameters.Remove('Debug')}
    Validate-ResourceProperties @PSBoundParameters -Apply
}

function Test-TargetResource
{
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param
    (
        [parameter(Mandatory)]
        [String]$SourceDomainName,

        [parameter(Mandatory)]
        [String]$TargetDomainName,

        [parameter(Mandatory)]
        [PSCredential]$TargetDomainAdministratorCredential,

        [parameter(Mandatory)]
        [ValidateSet("External","Forest")]
        [String]$TrustType,

        [parameter(Mandatory)]
        [ValidateSet("Bidirectional","Inbound","Outbound")]
        [String]$TrustDirection,

        [ValidateSet("Present","Absent")]
        [String]$Ensure = 'Present'
    )

#region Input Validation

    # Load the .NET assembly
    try
    {
        Add-type -AssemblyName System.DirectoryServices
    }
    # If not found, means ADDS role is not installed
    catch
    {
        $missingRoleMessage = $($LocalizedData.MissingRoleMessage) -f 'AD-Domain-Services' 
        New-TerminatingError -errorId ActiveDirectoryRoleMissing -errorMessage $missingRoleMessage -errorCategory NotInstalled
    }

#endregion

    if($PSBoundParameters.ContainsKey('Debug')){$null = $PSBoundParameters.Remove('Debug')}
    Validate-ResourceProperties @PSBoundParameters
}

#region Helper Functions
function Validate-ResourceProperties
{
    [Cmdletbinding()]
    param
    (
        [parameter(Mandatory)]
        [String]$SourceDomainName,

        [parameter(Mandatory)]
        [String]$TargetDomainName,

        [parameter(Mandatory)]
        [PSCredential]$TargetDomainAdministratorCredential,

        [parameter(Mandatory)]
        [ValidateSet("External","Forest")]
        [String]$TrustType,

        [parameter(Mandatory)]
        [ValidateSet("Bidirectional","Inbound","Outbound")]
        [String]$TrustDirection,

        [ValidateSet("Present","Absent")]
        [String]$Ensure = 'Present',

        [Switch]$Apply
    )

    try
    {
        $checkingTrustMessage = $($LocalizedData.CheckingTrustMessage) -f $SourceDomainName,$TargetDomainName
        Write-Verbose -Message $checkingTrustMessage

        switch ($TrustType)
        {
            'External' {$DomainOrForest = 'Domain'}
            'Forest' {$DomainOrForest = 'Forest'}
        }
        # Create the target object
        $trgDirectoryContext = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext($DomainOrForest,$TargetDomainName, $TargetDomainAdministratorCredential.UserName, $TargetDomainAdministratorCredential.GetNetworkCredential().Password)
        $trgDomain = ([type]"System.DirectoryServices.ActiveDirectory.$DomainOrForest")::"Get$DomainOrForest"($trgDirectoryContext)
        # Create the source object
        $srcDirectoryContext = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext($DomainOrForest,$SourceDomainName)
        $srcDomain = ([type]"System.DirectoryServices.ActiveDirectory.$DomainOrForest")::"Get$DomainOrForest"($srcDirectoryContext)

        # Find trust
        try
        {
            # Find trust betwen source & destination.
            $trust = $srcDomain.GetTrustRelationship($TargetDomainName)
        
            $TestTrustMessage = $($LocalizedData.TestTrustMessage) -f 'present',$Ensure
            Write-Verbose -Message $TestTrustMessage

            if($Ensure -eq 'Present')
            {
                #region Test for trust direction

                $CheckPropertyMessage = $($LocalizedData.CheckPropertyMessage) -f 'trust direction'
                Write-Verbose -Message $CheckPropertyMessage
             
                # Set the trust direction if not correct
                if($trust.TrustDirection -ne $TrustDirection)
                {
                    $notDesiredPropertyMessage = $($LocalizedData.NotDesiredPropertyMessage) -f 'Trust direction',$TrustDirection,$trust.TrustDirection
                    Write-Verbose -Message $notDesiredPropertyMessage

                    if($Apply)
                    {
                        $srcDomain.UpdateTrustRelationship($trgDomain,$TrustDirection)

                        $setPropertyMessage = $($LocalizedData.SetPropertyMessage) -f 'Trust direction'
                        Write-Verbose -Message $setPropertyMessage
                    }
                    else
                    {
                        return $false
                    }
                } # end trust direction is not correct
            
                # Trust direction is correct
                else
                {
                    $desiredPropertyMessage = $($LocalizedData.DesiredPropertyMessage) -f 'Trust direction'
                    Write-Verbose -Message $desiredPropertyMessage
                }
                #endregion trust direction
             
                #region Test for trust type

                $CheckPropertyMessage = $($LocalizedData.CheckPropertyMessage) -f 'trust type'
                Write-Verbose -Message $CheckPropertyMessage
             
                # Set the trust type if not correct
                if($trust.TrustType-ne $TrustType)
                {
                    $notDesiredPropertyMessage = $($LocalizedData.NotDesiredPropertyMessage) -f 'Trust type',$TrustType,$trust.TrustType
                    Write-Verbose -Message $notDesiredPropertyMessage

                    if($Apply)
                    {
                        # Only way to fix the trust direction is to delete it and create again
                        # TODO: Add a property to ask user permission to delete an existing trust
                        $srcDomain.DeleteTrustRelationship($trgDomain)
                        $srcDomain.CreateTrustRelationship($trgDomain,$TrustDirection)

                        $setPropertyMessage = $($LocalizedData.SetPropertyMessage) -f 'Trust type'
                        Write-Verbose -Message $setPropertyMessage
                    }
                    else
                    {
                        return $false
                    }
                } # end trust type is not correct
            
                # Trust type is correct
                else
                {
                    $desiredPropertyMessage = $($LocalizedData.DesiredPropertyMessage) -f 'Trust type'
                    Write-Verbose -Message $desiredPropertyMessage
                }

                #endregion Test for trust type

                # If both trust type and trust direction are correct, return true
                if(-not $Apply)
                {
                    return $true
                }                
            } # end Ensure -eq present
 
            # If the trust should be absent, remove the trust
            else
            {                                                    
                if($Apply)
                {
                    $removingTrustMessage = $($LocalizedData.RemovingTrustMessage) -f $SourceDomainName,$TargetDomainName
                    Write-Verbose -Message $removingTrustMessage

                    $srcDomain.DeleteTrustRelationship($trgDomain)

                    $deleteTrustMessage = $LocalizedData.DeleteTrustMessage
                    Write-Verbose -Message $deleteTrustMessage
                }
                else
                {
                    return $false
                }
            } # end Ensure -eq absent
        } # end find trust

        # Trust does not exist between source and destination
        catch [System.DirectoryServices.ActiveDirectory.ActiveDirectoryObjectNotFoundException]
        {
            $TestTrustMessage = $($LocalizedData.TestTrustMessage) -f 'absent',$Ensure
            Write-Verbose -Message $TestTrustMessage

            if($Ensure -eq 'Present')
            {
                if($Apply)
                {
                    $addingTrustMessage = $($LocalizedData.AddingTrustMessage) -f $SourceDomainName,$TargetDomainName
                    Write-Verbose -Message $addingTrustMessage
            
                    $srcDomain.CreateTrustRelationship($trgDomain,$TrustDirection)

                    $setTrustMessage = $LocalizedData.SetTrustMessage
                    Write-Verbose -Message $setTrustMessage
                }
                else
                {
                    return $false
                }
            } # end Ensure -eq Present
            else
            {
                if(-not $Apply)
                {
                    return $true
                }
            }
        } # end no trust
    }# end getting directory object
    catch [System.DirectoryServices.ActiveDirectory.ActiveDirectoryObjectNotFoundException]
    {
        throw
    }
}

# Internal function to throw terminating error with specified errroCategory, errorId and errorMessage
function New-TerminatingError
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory)]
        [String]$errorId,
        
        [Parameter(Mandatory)]
        [String]$errorMessage,

        [Parameter(Mandatory)]
        [System.Management.Automation.ErrorCategory]$errorCategory
    )
    
    $exception = New-Object System.InvalidOperationException $errorMessage 
    $errorRecord = New-Object System.Management.Automation.ErrorRecord $exception, $errorId, $errorCategory, $null
    throw $errorRecord
}

#endregion

Export-ModuleMember -Function *-TargetResource

# SIG # Begin signature block
# MIIkAwYJKoZIhvcNAQcCoIIj9DCCI/ACAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDmqdOI4tozgigP
# dvgTf5r/IpOF2GElBaCfnPmRBKS6VKCCDZIwggYQMIID+KADAgECAhMzAAAAZEeE
# lIbbQRk4AAAAAABkMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTUxMDI4MjAzMTQ2WhcNMTcwMTI4MjAzMTQ2WjCBgzEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjENMAsGA1UECxMETU9Q
# UjEeMBwGA1UEAxMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAky7a2OY+mNkbD2RfTahYTRQ793qE/DwRMTrvicJK
# LUGlSF3dEp7vq2YoNNV9KlV7TE2K8sDxstNSFYu2swi4i1AL3X/7agmg3GcExPHf
# vHUYIEC+eCyZVt3u9S7dPkL5Wh8wrgEUirCCtVGg4m1l/vcYCo0wbU06p8XzNi3u
# XyygkgCxHEziy/f/JCV/14/A3ZduzrIXtsccRKckyn6B5uYxuRbZXT7RaO6+zUjQ
# hiyu3A4hwcCKw+4bk1kT9sY7gHIYiFP7q78wPqB3vVKIv3rY6LCTraEbjNR+phBQ
# EL7hyBxk+ocu+8RHZhbAhHs2r1+6hURsAg8t4LAOG6I+JQIDAQABo4IBfzCCAXsw
# HwYDVR0lBBgwFgYIKwYBBQUHAwMGCisGAQQBgjdMCAEwHQYDVR0OBBYEFFhWcQTw
# vbsz9YNozOeARvdXr9IiMFEGA1UdEQRKMEikRjBEMQ0wCwYDVQQLEwRNT1BSMTMw
# MQYDVQQFEyozMTY0Mis0OWU4YzNmMy0yMzU5LTQ3ZjYtYTNiZS02YzhjNDc1MWM0
# YjYwHwYDVR0jBBgwFoAUSG5k5VAF04KqFzc3IrVtqMp1ApUwVAYDVR0fBE0wSzBJ
# oEegRYZDaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jcmwvTWljQ29k
# U2lnUENBMjAxMV8yMDExLTA3LTA4LmNybDBhBggrBgEFBQcBAQRVMFMwUQYIKwYB
# BQUHMAKGRWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2VydHMvTWlj
# Q29kU2lnUENBMjAxMV8yMDExLTA3LTA4LmNydDAMBgNVHRMBAf8EAjAAMA0GCSqG
# SIb3DQEBCwUAA4ICAQCI4gxkQx3dXK6MO4UktZ1A1r1mrFtXNdn06DrARZkQTdu0
# kOTLdlGBCfCzk0309RLkvUgnFKpvLddrg9TGp3n80yUbRsp2AogyrlBU+gP5ggHF
# i7NjGEpj5bH+FDsMw9PygLg8JelgsvBVudw1SgUt625nY7w1vrwk+cDd58TvAyJQ
# FAW1zJ+0ySgB9lu2vwg0NKetOyL7dxe3KoRLaztUcqXoYW5CkI+Mv3m8HOeqlhyf
# FTYxPB5YXyQJPKQJYh8zC9b90JXLT7raM7mQ94ygDuFmlaiZ+QSUR3XVupdEngrm
# ZgUB5jX13M+Pl2Vv7PPFU3xlo3Uhj1wtupNC81epoxGhJ0tRuLdEajD/dCZ0xIni
# esRXCKSC4HCL3BMnSwVXtIoj/QFymFYwD5+sAZuvRSgkKyD1rDA7MPcEI2i/Bh5O
# MAo9App4sR0Gp049oSkXNhvRi/au7QG6NJBTSBbNBGJG8Qp+5QThKoQUk8mj0ugr
# 4yWRsA9JTbmqVw7u9suB5OKYBMUN4hL/yI+aFVsE/KJInvnxSzXJ1YHka45ADYMK
# AMl+fLdIqm3nx6rIN0RkoDAbvTAAXGehUCsIod049A1T3IJyUJXt3OsTd3WabhIB
# XICYfxMg10naaWcyUePgW3+VwP0XLKu4O1+8ZeGyaDSi33GnzmmyYacX3BTqMDCC
# B3owggVioAMCAQICCmEOkNIAAAAAAAMwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29m
# dCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDExMB4XDTExMDcwODIwNTkw
# OVoXDTI2MDcwODIxMDkwOVowfjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEoMCYGA1UEAxMfTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAx
# MTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAKvw+nIQHC6t2G6qghBN
# NLrytlghn0IbKmvpWlCquAY4GgRJun/DDB7dN2vGEtgL8DjCmQawyDnVARQxQtOJ
# DXlkh36UYCRsr55JnOloXtLfm1OyCizDr9mpK656Ca/XllnKYBoF6WZ26DJSJhIv
# 56sIUM+zRLdd2MQuA3WraPPLbfM6XKEW9Ea64DhkrG5kNXimoGMPLdNAk/jj3gcN
# 1Vx5pUkp5w2+oBN3vpQ97/vjK1oQH01WKKJ6cuASOrdJXtjt7UORg9l7snuGG9k+
# sYxd6IlPhBryoS9Z5JA7La4zWMW3Pv4y07MDPbGyr5I4ftKdgCz1TlaRITUlwzlu
# ZH9TupwPrRkjhMv0ugOGjfdf8NBSv4yUh7zAIXQlXxgotswnKDglmDlKNs98sZKu
# HCOnqWbsYR9q4ShJnV+I4iVd0yFLPlLEtVc/JAPw0XpbL9Uj43BdD1FGd7P4AOG8
# rAKCX9vAFbO9G9RVS+c5oQ/pI0m8GLhEfEXkwcNyeuBy5yTfv0aZxe/CHFfbg43s
# TUkwp6uO3+xbn6/83bBm4sGXgXvt1u1L50kppxMopqd9Z4DmimJ4X7IvhNdXnFy/
# dygo8e1twyiPLI9AN0/B4YVEicQJTMXUpUMvdJX3bvh4IFgsE11glZo+TzOE2rCI
# F96eTvSWsLxGoGyY0uDWiIwLAgMBAAGjggHtMIIB6TAQBgkrBgEEAYI3FQEEAwIB
# ADAdBgNVHQ4EFgQUSG5k5VAF04KqFzc3IrVtqMp1ApUwGQYJKwYBBAGCNxQCBAwe
# CgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0j
# BBgwFoAUci06AjGQQ7kUBU7h6qfHMdEjiTQwWgYDVR0fBFMwUTBPoE2gS4ZJaHR0
# cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljUm9vQ2Vy
# QXV0MjAxMV8yMDExXzAzXzIyLmNybDBeBggrBgEFBQcBAQRSMFAwTgYIKwYBBQUH
# MAKGQmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2Vy
# QXV0MjAxMV8yMDExXzAzXzIyLmNydDCBnwYDVR0gBIGXMIGUMIGRBgkrBgEEAYI3
# LgMwgYMwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lv
# cHMvZG9jcy9wcmltYXJ5Y3BzLmh0bTBABggrBgEFBQcCAjA0HjIgHQBMAGUAZwBh
# AGwAXwBwAG8AbABpAGMAeQBfAHMAdABhAHQAZQBtAGUAbgB0AC4gHTANBgkqhkiG
# 9w0BAQsFAAOCAgEAZ/KGpZjgVHkaLtPYdGcimwuWEeFjkplCln3SeQyQwWVfLiw+
# +MNy0W2D/r4/6ArKO79HqaPzadtjvyI1pZddZYSQfYtGUFXYDJJ80hpLHPM8QotS
# 0LD9a+M+By4pm+Y9G6XUtR13lDni6WTJRD14eiPzE32mkHSDjfTLJgJGKsKKELuk
# qQUMm+1o+mgulaAqPyprWEljHwlpblqYluSD9MCP80Yr3vw70L01724lruWvJ+3Q
# 3fMOr5kol5hNDj0L8giJ1h/DMhji8MUtzluetEk5CsYKwsatruWy2dsViFFFWDgy
# cScaf7H0J/jeLDogaZiyWYlobm+nt3TDQAUGpgEqKD6CPxNNZgvAs0314Y9/HG8V
# fUWnduVAKmWjw11SYobDHWM2l4bf2vP48hahmifhzaWX0O5dY0HjWwechz4GdwbR
# BrF1HxS+YWG18NzGGwS+30HHDiju3mUv7Jf2oVyW2ADWoUa9WfOXpQlLSBCZgB/Q
# ACnFsZulP0V3HjXG0qKin3p6IvpIlR+r+0cjgPWe+L9rt0uX4ut1eBrs6jeZeRhL
# /9azI2h15q/6/IvrC4DqaTuv/DDtBEyO3991bWORPdGdVk5Pv4BXIqF4ETIheu9B
# CrE/+6jMpF3BoYibV3FWTkhFwELJm3ZbCoBIa/15n8G9bW1qyVJzEw16UM0xghXH
# MIIVwwIBATCBlTB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQ
# MA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9u
# MSgwJgYDVQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExAhMzAAAA
# ZEeElIbbQRk4AAAAAABkMA0GCWCGSAFlAwQCAQUAoIG4MBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCCvvUGognHKT9Gw3v9CstUQROWFd8GUfRysfsgrFxxzxDBMBgor
# BgEEAYI3AgEMMT4wPKASgBAATQBTAEkAVAAgAEEAUgBNoSaAJGh0dHBzOi8vZ2l0
# aHViLmNvbS9taWNyb3NvZnQvbXNpdGFybTANBgkqhkiG9w0BAQEFAASCAQB1NqWZ
# FcAsOAs9cMOpa63d/6FyHubCMP8RmzJlXi56PspyFNZlgujsjqTksNmAhmTmjJvZ
# 0BmyiSJnyJB20LGxsMlX8JzBBITiG8GlR1gCocMMbXc0MuUT5n6JCmswYZuiZky/
# bSptvi1oVpajIZLD7RCnTbv+qFNPe0i+DyUzXHQrq7lT7ayhvGOK5zJkuPr7Xlwj
# mVr/AcsCg5Y6GN8WseXBjIkt2H/yyXpwQPhWzVk1DYKC+izk964prxVTipJik1xz
# HGtCPGoWfvnAMcKjsS8IFP9qHI4fBFDkVCzXtYppBgxN/YSqEXO1zei5jZJZQPBS
# 2hdavx7NxoZAPU0boYITRzCCE0MGCisGAQQBgjcDAwExghMzMIITLwYJKoZIhvcN
# AQcCoIITIDCCExwCAQMxDzANBglghkgBZQMEAgEFADCCAToGCyqGSIb3DQEJEAEE
# oIIBKQSCASUwggEhAgEBBgorBgEEAYRZCgMBMDEwDQYJYIZIAWUDBAIBBQAEIDN6
# ASqkuNaf2tG8J7pE2hHqspWSkHV/7E/yH+ei3SHVAgZXvINfU+0YEzIwMTYwODMx
# MjEzNjQwLjA0OVowBIACAfSggbmkgbYwgbMxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIxJzAlBgNVBAsTHm5DaXBoZXIg
# RFNFIEVTTjoxNDhDLUM0QjktMjA2NjElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgU2VydmljZaCCDs0wggZxMIIEWaADAgECAgphCYEqAAAAAAACMA0GCSqG
# SIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQ
# MA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9u
# MTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkg
# MjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2NTVaMHwxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBU
# aW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC
# AQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvtfGhLLF/Fw+Vhwna3PmYr
# W/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzXTbg4CLNC3ZOs1nMwVyaC
# o0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+TTJLBxKZd0WETbijGGvmG
# gLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9ikJNQFHRD5wGPmd/9WbA
# A5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDpmc085y9Euqf03GS9pAHB
# IAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIwEAYJKwYBBAGCNxUBBAMC
# AQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1VMBkGCSsGAQQBgjcUAgQM
# HgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1Ud
# IwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0
# dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0Nl
# ckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKG
# Pmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0
# XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIwgY8GCSsGAQQBgjcuAzCB
# gTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL1BLSS9kb2Nz
# L0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIgHQBMAGUAZwBhAGwAXwBQ
# AG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4gHTANBgkqhkiG9w0BAQsF
# AAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7PBeKp/vpXbRkws8LFZslq
# 3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2zEBAQZvcXBf/XPleFzWY
# JFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95gWXZqbVr5MfO9sp6AG9L
# MEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7Yl+a21dA6fHOmWaQjP9q
# Yn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt0uGc+R38ONiU9MalCpaG
# pL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2onGqBooPiRa6YacRy5rY
# DkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA3+cxB6STOvdlR3jo+KhI
# q/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7G4kqVDmyW9rIDVWZeodz
# OwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Kiyc8ZQU3ghvkqmqMRZjDT
# u3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5XwdHeMMD9zOZN+w2/XU/p
# nR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P3nSISRIwggTaMIIDwqAD
# AgECAhMzAAAAiUn1DOTxi5SzAAAAAACJMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTE2MDMzMDE5MjQyNloXDTE3MDYzMDE5
# MjQyNlowgbMxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTAL
# BgNVBAsTBE1PUFIxJzAlBgNVBAsTHm5DaXBoZXIgRFNFIEVTTjoxNDhDLUM0Qjkt
# MjA2NjElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCASIw
# DQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAL5+QbX38cc1ITtOV04eOCBc9arc
# VScOsR9CN6d6fYab/E62CW095yggfRoZGhvLk2IboLEuJkUDfKerHhf7UIeAFfMB
# 42oB6Fatbth+kGc+9YrcutqjjoMxjtlCrZziESdJPhI/WWyWrSF+mSeSubHjdGY0
# JCCg+xlNctABsrbhuAdqT61hyh3g3jCaPjuHXGvgATVMvbJhDb7QPQ4cPFBScZFb
# IhV6FKgWr5WQVCGDofLSqIh+itty0vNjyDe/PEQBoJEspx6q+agDg3yyqvf2kP/C
# KZKkyQ8UhQkuTTJt1ZfFZoXEjoHqoXdM3LvvoYQq/lIR6v+hTfF5/Unj8EMCAwEA
# AaOCARswggEXMB0GA1UdDgQWBBTVwPpBFF2X1055Ctmbh6S/V/5TsDAfBgNVHSME
# GDAWgBTVYzpcijGQ80N7fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEugSaBHhkVodHRw
# Oi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNUaW1TdGFQ
# Q0FfMjAxMC0wNy0wMS5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5o
# dHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1RpbVN0YVBDQV8y
# MDEwLTA3LTAxLmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMI
# MA0GCSqGSIb3DQEBCwUAA4IBAQCjUyzo/BB549H8Oyjz0xe+uhkJxPvVC5rWY85m
# EmU+lJgOxG6AQO7sF2VQ3Z4MFwcQnMcAFKofyFj6AN+drRjwr2F30VxhxeYDOxaW
# VLbQY9YVl3sTtt23DKA03c5bCkMGK3wHc/oWB7PSkGDhyTGrPMWZjD7IMAQGc8G+
# rgN82ijxCmHTnAhlpNO1v0YV3CWLjLm7IVNx/2dy+tTMpitHpnPaf17UWuF0xccs
# TgEAvd3rehLEdnylm/eoYRyvk2bjc1Jkj7h/agu6Q8HFY3vnGLQx+8/i1iD94j6T
# ZINkbWx0D+glDTFt4ei7p9C30Wpon3dq4fqOUOfuzf/FOWWvoYIDdjCCAl4CAQEw
# geOhgbmkgbYwgbMxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# DTALBgNVBAsTBE1PUFIxJzAlBgNVBAsTHm5DaXBoZXIgRFNFIEVTTjoxNDhDLUM0
# QjktMjA2NjElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaIl
# CgEBMAkGBSsOAwIaBQADFQCGWJJE6T6Be+eg2QB44EL7fKLK6KCBwjCBv6SBvDCB
# uTELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjENMAsGA1UECxME
# TU9QUjEnMCUGA1UECxMebkNpcGhlciBOVFMgRVNOOjRERTktMEM1RS0zRTA5MSsw
# KQYDVQQDEyJNaWNyb3NvZnQgVGltZSBTb3VyY2UgTWFzdGVyIENsb2NrMA0GCSqG
# SIb3DQEBBQUAAgUA23GK8jAiGA8yMDE2MDgzMTE2NTcyMloYDzIwMTYwOTAxMTY1
# NzIyWjB0MDoGCisGAQQBhFkKBAExLDAqMAoCBQDbcYryAgEAMAcCAQACAgDEMAcC
# AQACAhvzMAoCBQDbctxyAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkK
# AwGgCjAIAgEAAgMHoSChCjAIAgEAAgMHoSAwDQYJKoZIhvcNAQEFBQADggEBACVA
# 0nIkrgcCubR5L9bj8g/GSmuixewywzVgt6zcFJi4Rhb2fnh90UifRDeULK0QRs6d
# d2umzI7VuMqyMI7UWTS1bwZ5o3aNediLOLrF8dz619inKpGIVGtyqnUjD48minZF
# r1ZAOKjJdD/3JvUnzIaZ78ksoRpG4zzbHr9JNFB1azKBEIVIFamNtbgdYzMk5MRz
# U09hsBLc1raXCBxf6vCCCR732kUaJnw0M1R5uruvD6Nk3BxhZsMyCVlVdlkL6crf
# 50OAMIUZi4FPX8mO3qWt54VbosBqzZKQpf+d8KIr0JivESUZwsfSeIOsdnnZR/U2
# VXkbHqngXqlvxYGwIpkxggL1MIIC8QIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFt
# cCBQQ0EgMjAxMAITMwAAAIlJ9Qzk8YuUswAAAAAAiTANBglghkgBZQMEAgEFAKCC
# ATIwGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCCT
# e9xyXD9pNHGQfZLdCzhwAwlJDea7e1tBwldqH0C7QjCB4gYLKoZIhvcNAQkQAgwx
# gdIwgc8wgcwwgbEEFIZYkkTpPoF756DZAHjgQvt8osroMIGYMIGApH4wfDELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAACJSfUM5PGLlLMAAAAAAIkwFgQU
# 9FsFMJMcDJeKNnuFOp4Vyem+gkwwDQYJKoZIhvcNAQELBQAEggEAmhfkgmsCuCVn
# /CBw1PgtavLdCDBMEsCslkIHJI8HCtr2N7PsDcHbOUoQIH0hPjrGIfDN1Auxt7Mz
# kpa5Wle9uAn0S/NfFpOoVR8ADXrN88ntHiiVM8KcAxb/647FNuNzFZcbfuwPzbVi
# atHzURcm1RkeqjZ4jgjrr+EORpcn/waB80Av3fzOgf580CkonyurdFrZ+BVvM+U/
# jmorG+JYDztfZJ8gjayWVaVJ+ftoPt6lDFdChPJikSzgrdufVnJ2mUg5h/6S2k8P
# fefWxUmc43uX3zwRpPIQmwI39lOKCmv3w9+A2u84TEK3Uzloae2KmLBu8LE1cLAJ
# vT9hJ7RWwA==
# SIG # End signature block
