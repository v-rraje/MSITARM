
Configuration DeploySQLServer
{
  param (  
   $Disks
  )

  Node localhost
  {
	   
   
    Script ConfigureSQLServerLocal{
            GetScript = {
                @{
                }
            }

            SetScript = {
               $sqlInstances = gwmi win32_service -computerName localhost -ErrorAction SilentlyContinue | ? { $_.Name -match "mssql*" -and $_.PathName -match "sqlservr.exe" } | % { $_.Caption }
               $ret = $false

                if($sqlInstances -ne $null -and $sqlInstances -gt 0){


                    #
                    # Start
                    #

                    cd\
                    md Temp
                    $sw = New-Object System.IO.StreamWriter(�C:\Temp\sqlinstall.log�)
                    $sw.WriteLine("$(Get-Date -Format g) This is your log file.")    

                    try{      
                
                        $ErrorActionPreference = "SilentlyContinue"
       
                        #
                        # Drive configuration
                        #
                        $sw.WriteLine("$(Get-Date -Format g) Configuring data disks...")


                        # Change E: => F:
                        $sw.WriteLine("$(Get-Date -Format g) Change E: => F:...")
                        $drive = Get-WmiObject -Class win32_volume -Filter "DriveLetter = 'E:'"
                        Set-WmiInstance -input $drive -Arguments @{DriveLetter="F:"} -ErrorAction Continue

                        # Change S: => E:
                        $sw.WriteLine("$(Get-Date -Format g) Change S: => E:...")
                        $drive = Get-WmiObject -Class win32_volume -Filter "DriveLetter = 'S:'"
                        Set-WmiInstance -input $drive -Arguments @{DriveLetter="E:"} -ErrorAction Continue


                        #
                        # SQL COnfiguration
                        #

                        $sw.WriteLine("$(Get-Date -Format g) Configuring SQL...")
                                                  
                        [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo") 
                        [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO")
                        [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended")

                        $srvConn = New-Object Microsoft.SqlServer.Management.Common.ServerConnection $env:computername
 
                        $srvConn.connect();
                        $srv = New-Object Microsoft.SqlServer.Management.Smo.Server $srvConn
                        
                        #  Set the backup location to E:
                        $sw.WriteLine("$(Get-Date -Format g) Set Backup location to E:")

                        $BackupDir = $srv.BackupDirectory
                        $BackupDir = $BackupDir -Replace "C:" , "E:"

                        $Path = $BackupDir -Replace "\\Backup", ""

                        $sw.WriteLine("$(Get-Date -Format g) Creating $($BackupDir)")

                        New-Item -path $Path -name "Backup" -itemType "directory"

                        $sw.WriteLine("$(Get-Date -Format g) Updating SQL...")
                        $srv.BackupDirectory = $BackupDir
                        $srv.Alter()

                        # Configure Temp DB:  num of data files = num of procs, equi-sized, autogrow

                        $drive = Get-WmiObject -Class win32_volume -Filter "DriveLetter = 'T:'"
                        if ($drive){

                            $sw.WriteLine("$(Get-Date -Format g) Configuting Temp DB on T:...")

	                        # get the spavce avail on T: and subtract 50 GB.  From that, divide it up to the number of files:
                            $FreeSpaceGB = (Get-WmiObject -Class win32_volume -Filter "DriveLetter = 'T:'").FreeSpace / 1024 / 1024 / 1024
                            $TempDBSpaceAvailGB = $FreeSpaceGB - 50
	                        $TempDBSpaceAvailMB = $TempDBSpaceAvailGB * 1024

                            $cpu =  Get-WmiObject -class win32_processor -Property 'numberofcores'
                            $fileCount = $cpu.NumberOfCores

                            $maxFileGrowthSizeMB = $TempDBSpaceAvailMB / $fileCount 
                            $maxFileGrowthSizeMB = [math]::truncate($maxFileGrowthSizeMB)
	                        $fileSize     = '1000'
                            $fileGrowthMB = '50'            

                            $TempPath = $Srv.RootDirectory -Replace "C:", "T:"
	                        $TempPath = $TempPath + '\'

	                        #create the folder for our temp db files
                            $sw.WriteLine("$(Get-Date -Format g) Creating $($TempPath)")
                            New-Item -path $TempPath -name "Data" -itemType "directory"

	                        #build the sql command to move/create the files and invoke them...
	
	                        # 1st data file	
                            $sw.WriteLine("$(Get-Date -Format g) Moving first data file...")	
	                        $q = "ALTER DATABASE [tempdb]          MODIFY FILE ( NAME = tempdev,   SIZE = $($fileSize)MB, MAXSIZE = $($maxFileGrowthSizeMB)MB, FILEGROWTH = $($fileGrowthMB)MB, FILENAME = '$($TempPath)data\tempdb.mdf')"
	                        Invoke-Sqlcmd $q

	                        # remaining data files
	                        $sw.WriteLine("$(Get-Date -Format g) Creating remaining data files...")	
                            for ($i = 2; $i -le $fileCount; $i++) {

		                        $q = "ALTER DATABASE [tempdb] ADD FILE ( NAME = tempdev$($i), SIZE = $($fileSize)MB, MAXSIZE = $($maxFileGrowthSizeMB)MB, FILEGROWTH = $($fileGrowthMB)MB, FILENAME = '$($TempPath)data\tempdb$($i).mdf')"; 
		                        Invoke-Sqlcmd $q
	                        }
	
	                        # log file
                            $sw.WriteLine("$(Get-Date -Format g) Moving log file...")	
	                        $q = "ALTER DATABASE [tempdb]          MODIFY FILE ( NAME = templog,   SIZE = $($fileSize)MB, MAXSIZE = $($maxFileGrowthSizeMB)MB, FILEGROWTH = $($fileGrowthMB)MB, FILENAME = '$($TempPath)data\templog.ldf')"
	                        Invoke-Sqlcmd $q
                            
                            $sw.WriteLine("$(Get-Date -Format g) Restarting SQL Server.")	

                            net stop mssqlserver
                            Start-Sleep 15
                            net start mssqlserver
                            
                        }


                        <#
                        $srv.Settings.DefaultFile.Value = $using:Disks.SQLServer.DataPath.value
                        $srv.Settings.DefaultLog.Value = $using:Disks.SQLServer.LogPath.value
                        $srv.Properties["BackupDirectory"].Value = $using:Disks.SQLServer.backupPath.value
                        $srv.Alter()
                        #>

                    }

                    catch {
                    
                        [string]$errorMessage = $Error[0].Exception
		                $sw.WriteLine("$(Get-Date -Format g) An error occurred: $($errorMessage)")
        
                    }
                    
                    finally{
        
                        $ErrorActionPreference = 'Stop'
            
                    }

                    #
                    # Wrap it up
                    #
                    
                    $sw.WriteLine("$(Get-Date -Format g) Fin.")	
                    $sw.Close()
                
                }
            
            }

            TestScript = {$false}
            
        }

    }

}
